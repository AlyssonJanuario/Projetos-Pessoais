const start = document.querySelector('#button')
const form = document.querySelector('form')
let intervalID

const executarCodigo = () => {
    function autoClick(botao) {                 
        if (botao) {              
            botao.click()
        } else {                
            console.error('Botão não encontrado')
        }        
    }

    intervalID = setInterval(() => {
        var botao = document.querySelector('[data-test-id="views_views-list_header-refresh"]')
        autoClick(botao)
    }, 2000)
}

const pararCodigo = () => {
    clearInterval(intervalID)
}

start.addEventListener('click', () => {
    form.addEventListener('submit', async (event) => {
        event.preventDefault()
    
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
    
        chrome.scripting.executeScript({
            target: { tabId: tab.id },
            function: executarCodigo
        })
    })
})


const stop = document.querySelector('#button1')
stop.addEventListener('click', () => {
    form.addEventListener('submit', async (event) => {
        event.preventDefault()
    
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
    
        chrome.scripting.executeScript({
            target: { tabId: tab.id },
            function: pararCodigo
        })
    })
})